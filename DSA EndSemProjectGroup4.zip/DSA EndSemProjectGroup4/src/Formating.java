import javax.swing.*;
import java.awt.*;

public class Formating {
    private static JTextArea area;
    static {
        area = Frames.getTextArea();
    }

    // setting font
    public static void setFont(String name) {
        area.setFont(new Font(name, area.getFont().getStyle(), area.getFont().getSize()));
    }

    // setting font style
    public static void setFontStyle(int style) {
        area.setFont(new Font(area.getFont().getName(), style, area.getFont().getSize()));
    }

    // setting font size
    public static void setSize(int size) {
        area.setFont(new Font(area.getFont().getName(), area.getFont().getStyle(), size));
    }

    // setting background colour
    public static Color getBackgroundColor() {
        return area.getBackground();
    }

    // setting text colour
    public static Color getTextColor() {
        return area.getForeground();
    }
}
