import java.awt.BorderLayout;
import java.awt.Point;
import java.awt.event.KeyEvent;

import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;

public class AutoSuggest {
    private SuggestionPanel suggestion;
    private JTextArea areaSug;

    AutoSuggest() {
        initUI();
    }

    public void showSuggestionLater() {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                showSuggestion();
            }
        });
    }

    protected void showSuggestion() {
        hideSuggestion();
        final int position = areaSug.getCaretPosition();
        Point location;
        try {
            location = areaSug.getLocation();
        } catch (Exception e) {
            e.printStackTrace();
            return;
        }
        String text = areaSug.getText();
        int start = Math.max(0, position - 1);
        while (start > 0) {
            if (!Character.isWhitespace(text.charAt(start))) {
                start--;
            } else {
                start++;
                break;
            }
        }
        if (start > position) {
            return;
        }
        final String subWord = text.substring(start, position);
        if (subWord.length() < 1) {
            return;
        }
        suggestion = new SuggestionPanel(areaSug, position, subWord, location, this);
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                areaSug.requestFocusInWindow();
            }
        });
    }

    public void hideSuggestion() {
        if (suggestion != null) {
            suggestion.hide();
        }
    }

    protected void initUI() {
        JPanel panel = new JPanel(new BorderLayout());
        this.areaSug = Frames.getTextArea();
    }

    public void OpenWordsSuggestion(KeyEvent e) {
        if (e.getKeyChar() == KeyEvent.VK_BACK_SPACE)
            hideSuggestion();
        if (e.getKeyChar() == KeyEvent.VK_ENTER) {
            if (suggestion != null) {
                if (suggestion.insertSelection()) {
                    e.consume();
                    final int position = areaSug.getCaretPosition();
                    SwingUtilities.invokeLater(new Runnable() {
                        public void run() {
                            try {
                                areaSug.getDocument().remove(position - 1, 1);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    });
                }
            }
        }
    }

    public void Movement(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_DOWN && suggestion != null) {
            suggestion.moveDown();
        } else if (e.getKeyCode() == KeyEvent.VK_UP && suggestion != null) {
            suggestion.moveUp();
        } else if (Character.isLetterOrDigit(e.getKeyChar())) {
            showSuggestionLater();
        } else if (Character.isWhitespace(e.getKeyChar())) {
            hideSuggestion();
        }
    }
}
